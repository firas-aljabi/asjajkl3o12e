<?php


namespace App\ApiHelper;


class EnumResult
{
    const Success = 1;
    const Not_Confirmed = 2;
    const Fail = 3;
    const NotFound = 4;
}
