<?php

namespace App\Interfaces\Admin;


interface AdminServiceInterface
{
    public function create_admin($data);
}
