<?php

namespace App\Interfaces\Receiption;


interface ReceiptionServiceInterface
{
    public function create_client($data);
}
