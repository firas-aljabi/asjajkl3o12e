<?php

namespace App\Filter\Service;

use App\Filter\OthersBaseFilter;

class ServiceFilter extends OthersBaseFilter
{
}
