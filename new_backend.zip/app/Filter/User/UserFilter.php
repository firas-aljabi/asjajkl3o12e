<?php

namespace App\Filter\User;

use App\Filter\OthersBaseFilter;

class UserFilter extends OthersBaseFilter
{
}
