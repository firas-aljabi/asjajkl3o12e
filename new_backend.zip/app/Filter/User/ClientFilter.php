<?php

namespace App\Filter\User;

use App\Filter\OthersBaseFilter;

class ClientFilter extends OthersBaseFilter
{
}